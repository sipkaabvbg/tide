package com.tide.mobile.controllers;

import com.tide.mobile.api.controller.MainController;
import static com.tide.mobile.controllers.Constants.INDEX_MEASSGE;

/**
 * MainController class
 * @author User
 *
 */
public class MainControllerImpl implements MainController{
	
  public String index() {
    return  INDEX_MEASSGE;
  }

}
