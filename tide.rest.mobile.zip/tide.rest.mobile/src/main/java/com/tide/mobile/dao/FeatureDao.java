package com.tide.mobile.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.tide.mobile.api.dao.FeatureDaoInterface;
import com.tide.mobile.domain.Feature;

/**
 * This class is used to access data for the Feature entity.
 *
 */
@Repository
public class FeatureDao implements FeatureDaoInterface{
	 
	  // An EntityManager will be automatically injected from entityManagerFactory
	  @PersistenceContext
	  private EntityManager entityManager;
	  
	  /**
	   * Save the feature in the database.
	   */
	  public void create(Feature feature) {
	    entityManager.persist(feature);
	  }
	  
	  /**
	   * Delete the feature from the database.
	   */
	  public void delete(Feature feature) {
	    if (entityManager.contains(feature)){
	      entityManager.remove(feature);
	    }else{
	      entityManager.remove(entityManager.merge(feature));
	    }
	  }
	  
	  /**
	   * Return all the features stored in the database.
	   */
	  @SuppressWarnings("unchecked")
	  public List<Feature> getAll() {
	    return entityManager.createQuery("from Feature").getResultList();
	  }
	  
	  /**
	   * Return the feature having the passed id.
	   */
	  public Feature getById(long id) {
	    return entityManager.find(Feature.class, id);
	  }

	  /**
	   * Update the passed feature in the database.
	   */
	  public void update(Feature feature) {
	    entityManager.merge(feature);
	  }
	  /**
	   * Return the feature having the passed name if exists.
	   */
	  public Feature getByName(String name) {
		  Feature feature=null;
		  try{
		  feature= (Feature) entityManager.createQuery(
			        "from Feature where name = :name")
			        .setParameter("name", name)
			        .getSingleResult();
			  
		  }catch(javax.persistence.NoResultException e){
			//No entity found for query!!;  
		  }
	    return feature;
	  }
	} 
