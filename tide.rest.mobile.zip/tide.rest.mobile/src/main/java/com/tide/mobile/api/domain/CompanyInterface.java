package com.tide.mobile.api.domain;

/**
 * This interface describes Company methods
 * @author User
 *
 */
public interface CompanyInterface {

}
