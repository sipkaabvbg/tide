package com.tide.mobile.api.domain;

import java.util.Set;

import com.tide.mobile.domain.Feature;

/**
 * This interface describes User methods
 * @author User
 *
 */
public interface UserInterface {

	public long getId();;

	public void setId(long value);

	public String getName();

	public void setName(String value);

	public Set<Feature> getFeatures();

	public void setFeatures(Set<Feature> features);
}
