package com.tide.mobile.api.dao;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.tide.mobile.domain.User;

/**
 * This interface describes UserDao methods
 * @author User
 *
 */
@Repository
@Transactional
public interface UserDaoInterface  {
	  
	 
	  /**
	   * Save the user in the database.
	   */
	  public long create(User user);
	  
	  /**
	   * Delete the user from the database.
	   */
	  public void delete(User user) ;
	  
	  /**
	   * Return all the users stored in the database.
	   */
	  public List<User> getAll();
	  /**
	   * Return the user having the passed id.
	   */
	  public User getById(long id);
	  /**
	   * Update the passed user in the database.
	   */
	  public void update(User user);
}
