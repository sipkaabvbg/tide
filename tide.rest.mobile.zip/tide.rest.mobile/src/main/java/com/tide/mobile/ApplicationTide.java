package com.tide.mobile;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main class
 * @author User
 *
 */
@SpringBootApplication
@EnableTransactionManagement
public class ApplicationTide {
	  
  public static void main(String[] args) {
    SpringApplication.run(ApplicationTide.class, args);
  }
}
