package com.tide.mobile.controllers;

import java.util.ArrayList;

/**
 * This class represents the object of ActiveFeatures
 * @author User
 *
 */
public class ActiveFeatures {

	private ArrayList<String> active_features;

	public ArrayList<String> getActiveFeatures() {
		if(active_features==null){
			active_features=new ArrayList<String>();
		} 
		return this.active_features;
	}

	public void setActiveFeatures(ArrayList<String> active_features) {
		this.active_features = active_features;
	}
}
