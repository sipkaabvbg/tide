package com.tide.mobile.api.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.async.DeferredResult;

/**
 * This interface describes UserController methods
 * 
 * @author User
 *
 */

public interface UserControllerInterface {

	/**
	 * Create a new user with an auto-generated id and name as passed values.
	 */
	@RequestMapping(value = "/create", 
			method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE, 
			params = {"name" })
	@ResponseBody
	public DeferredResult<ResponseEntity<?>> create(String name);

	/**
	 * Delete the user with the passed id.
	 */
	@RequestMapping(value = "/delete",
			method = RequestMethod.DELETE,
			produces = MediaType.APPLICATION_JSON_VALUE,
			params = {"userId" })
	@ResponseBody
	public DeferredResult<ResponseEntity<?>> delete(long userId);

	/**
	 * Add feature for the user with id with the passed feature name.
	 */
	@RequestMapping(value = "/add-feature", 
			method = RequestMethod.PUT,
			produces = MediaType.APPLICATION_JSON_VALUE,
			params = {"userId", "featureName" })
	@ResponseBody
	public DeferredResult<ResponseEntity<?>> addFeature(long userId, String featureName);

	/**
	 * Remove feature for the user with id with the passed feature name.
	 */
	@RequestMapping(value = "/remove-feature",
			method = RequestMethod.PUT, 
			produces = MediaType.APPLICATION_JSON_VALUE, 
			params = {"userId", "featureName" })
	@ResponseBody
	public DeferredResult<ResponseEntity<?>> removeFeature(long userId, String featureName);

	/**
	 * Update the name for the user indentified by the passed id.
	 */
	@RequestMapping(value = "/update", 
			method = RequestMethod.PUT,  
			produces = MediaType.APPLICATION_JSON_VALUE,
			params = {"userId", "name" })
	@ResponseBody
	public DeferredResult<ResponseEntity<?>> updateUser(long userId, String name);
}
