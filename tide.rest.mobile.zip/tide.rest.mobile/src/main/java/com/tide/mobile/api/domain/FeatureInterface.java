package com.tide.mobile.api.domain;

import java.util.Set;

import com.tide.mobile.domain.User;

/**
 * This interface describes Feature methods
 * @author User
 *
 */
public interface FeatureInterface {
	public long getId();

	public void setId(long value);

	public String getName();

	public void setName(String value);

	public String getDescription();

	public void setDescription(String description);

	public Set<User> getUsers();

	public void setUsers(Set<User> users);
}
