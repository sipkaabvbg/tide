package com.tide.mobile.api.domain;

/**
 * This interface describes MobileApp methods
 * @author User
 *
 */
public interface MobileAppInterface {

	public boolean isAppValid();
}
