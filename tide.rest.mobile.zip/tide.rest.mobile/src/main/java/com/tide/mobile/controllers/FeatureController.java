package com.tide.mobile.controllers;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.request.async.DeferredResult;

import com.google.gson.Gson;
import com.tide.mobile.api.controller.FeatureControllerInterface;
import com.tide.mobile.api.dao.FeatureDaoInterface;
import com.tide.mobile.api.dao.UserDaoInterface;
import com.tide.mobile.domain.Feature;
import com.tide.mobile.domain.User;
import static com.tide.mobile.controllers.Constants.FEATURE_DELETE_MEASSGE;
import static com.tide.mobile.controllers.Constants.FEATURE_UPDATE_MEASSGE;
import static com.tide.mobile.controllers.Constants.FEATURE_REGISTERED_MEASSGE;
/**
 * Class FeatureController
 */
@Controller
public class FeatureController implements FeatureControllerInterface {

	private final AtomicInteger counter = new AtomicInteger(0);
	// Wire the UserDao used inside this controller.
	@Autowired
	private UserDaoInterface userDao;
	// Wire the FeatureDao used inside this controller.
	@Autowired
	private FeatureDaoInterface featureDao;
	private DeferredResult<ResponseEntity<?>> result;
	/**
	 * Create a new Feature with an auto-generated id and description and name
	 * as passed values.
	 */
	public DeferredResult<ResponseEntity<?>> create(String name, String description) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(createFeature(name, description)));
		} , "Thread-create" + counter.incrementAndGet()).start();

		return result;
	}

	private String createFeature(String name, String description) {
		String featureId;
		Feature feature;
		try {
			if(featureDao.getByName(name)!=null){
				return FEATURE_REGISTERED_MEASSGE;
			}
			feature = new Feature(name, description);
			featureDao.create(feature);
			featureId = String.valueOf(feature.getId());
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"Error creating the feature: " + ex.getMessage() + "\"}";
		}
		return "{\"featureId\":"+featureId+"}";
	}

	/**
	 * Delete the feature with the passed id.
	 */

	public DeferredResult<ResponseEntity<?>> delete(long featureId) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(deleteFeature(featureId)));
		} , "Thread-create" + counter.incrementAndGet()).start();

		return result;
	}

	private String deleteFeature(long featureId) {
		Feature feature;
		try {
			feature = new Feature(featureId);
			featureDao.delete(feature);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"Error deleting the feature: " + ex.getMessage() + "\"}";
		}
		return FEATURE_DELETE_MEASSGE;
	}

	/**
	 * Retrieve the id for the feature with the passed name.
	 */

	public DeferredResult<ResponseEntity<?>> getByUser(long userId) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(getFeatureById(userId)));
		} , "Thread-create" + counter.incrementAndGet()).start();

		return result;
	}

	private String getFeatureById(long userId) {
		String json;
		ArrayList<String> activeFeatureResult;
		Set<Feature> setFeature;
		User user;
		ActiveFeatures activeFeature;
		try {
			user = userDao.getById(userId);
			setFeature = user.getFeatures();
			activeFeature = new ActiveFeatures();
			activeFeatureResult = activeFeature.getActiveFeatures();

			for (Feature feat : setFeature) {
				activeFeatureResult.add(feat.getName());
			}

			json = new Gson().toJson(activeFeature);
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
		return json;
	}

	/**
	 * Update the description and the name for the user indentified by the
	 * passed id.
	 */

	public DeferredResult<ResponseEntity<?>> updateName(long featureId, String featureName, String featureDescription) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(updateFeatureName(featureId, featureName, featureDescription)));
		} , "Thread-create" + counter.incrementAndGet()).start();

		return result;
	}

	private String updateFeatureName(long featureId, String featureName, String featureDescription) {
		Feature feature ;
		try {
			feature = featureDao.getById(featureId);
			feature.setDescription(featureDescription);
			feature.setName(featureName);
			featureDao.update(feature);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"Error updating the feature: " + ex.getMessage() + "\"}";
		}
		return FEATURE_UPDATE_MEASSGE;
	}
}
