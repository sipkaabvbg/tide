package com.tide.mobile.controllers;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.request.async.DeferredResult;

import com.tide.mobile.api.controller.UserControllerInterface;
import com.tide.mobile.api.dao.FeatureDaoInterface;
import com.tide.mobile.api.dao.UserDaoInterface;
import com.tide.mobile.domain.Feature;
import com.tide.mobile.domain.User;
import static com.tide.mobile.controllers.Constants.ADD_FEATURE_MESSAGE;
import static com.tide.mobile.controllers.Constants.REMOVE_FEATURE_MESSAGE;
import static com.tide.mobile.controllers.Constants.USER_DELETE_MESSAGE;
import static com.tide.mobile.controllers.Constants.USER_UPDATE_MESSAGE;
/**
 * Class UserController
 */
@Controller
public class UserController implements UserControllerInterface {
	
	private final AtomicInteger counter = new AtomicInteger(0);
	// Wire the UserDao used inside this controller.
	@Autowired
	private UserDaoInterface userDao;
	// Wire the FeatureDao used inside this controller.
	@Autowired
	private FeatureDaoInterface featureDao;
	private DeferredResult<ResponseEntity<?>> result;

	/**
	 * Create a new user with an auto-generated id and name as passed values.
	 */
	public DeferredResult<ResponseEntity<?>> create(String name) {

		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(createUser(name)));
		} , "Thread-create" + counter.incrementAndGet()).start();

		return result;

	}

	private String createUser(String name) {
		String userId;
		User user;
		try {
			user = new User(name);
			userDao.create(user);
			userId = String.valueOf(user.getId());
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"Error creating the user: " + ex.getMessage() + "\"}";
		}
		return "{\"userId\":" + userId + "}";
	}

	/**
	 * Delete the user with the passed id.
	 */

	public DeferredResult<ResponseEntity<?>> delete(long userId) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(deleteUser(userId)));
		} , "Thread-delete" + counter.incrementAndGet()).start();

		return result;
	}

	private String deleteUser(long userId) {
	
		User user;
		try {
			user = new User(userId);
			userDao.delete(user);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"Error deleting the user: " + ex.getMessage() + "\"}";
		}
		return USER_DELETE_MESSAGE;
	}

	/**
	 * Add feature for the user with id with the passed feature name.
	 */

	public DeferredResult<ResponseEntity<?>> addFeature(long userId, String featureName) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(addFeatureToUser(userId, featureName)));
		} , "Thread-add-feature" + counter.incrementAndGet()).start();

		return result;
	}

	private String addFeatureToUser(long userId, String featureName) {
		Feature feature;
		User user;
		try {
			feature = featureDao.getByName(featureName);
			user = userDao.getById(userId);
			user.getFeatures().add(feature);
			userDao.update(user);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"" + ex.getMessage() + "\"}";
		}
		return ADD_FEATURE_MESSAGE;
	}

	/**
	 * Remove feature for the user with id with the passed feature name.
	 */

	public DeferredResult<ResponseEntity<?>> removeFeature(long userId, String featureName) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(removeFeatureFromUser(userId, featureName)));
		} , "UserController" + counter.incrementAndGet()).start();

		return result;
	}

	private String removeFeatureFromUser(long userId, String featureName) {
		Set<Feature> set;
		Set<Feature> setNew;
		Feature feature;
		User user;
		try {
			feature = featureDao.getByName(featureName);
			user = userDao.getById(userId);
			set = user.getFeatures();
			setNew = new HashSet<>();
			for (Feature feat : set) {
				if (feat.getId() != feature.getId()) {
					setNew.add(feat);
				}
			}
			user.setFeatures(setNew);
			userDao.update(user);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"" + ex.getMessage() + "\"}";
		}
		return REMOVE_FEATURE_MESSAGE;
	}

	/**
	 * Update the name for the user indentified by the passed id.
	 */

	public DeferredResult<ResponseEntity<?>> updateUser(long userId, String name) {
		result = new DeferredResult<>();
		new Thread(() -> {
			result.setResult(ResponseEntity.ok(updateName(userId, name)));
		} , "Thread-update-User" + counter.incrementAndGet()).start();

		return result;
	}

	private String updateName(long userId, String name) {
		User user;
		try {
			user = userDao.getById(userId);
			user.setName(name);
			userDao.update(user);
		} catch (Exception ex) {
			ex.printStackTrace();
			return "{\"message\":\"Error updating the user: " + ex.getMessage() + "\"}";
		}
		return USER_UPDATE_MESSAGE;
	}
}
