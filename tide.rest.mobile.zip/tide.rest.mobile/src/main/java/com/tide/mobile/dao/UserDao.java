package com.tide.mobile.dao;

import java.util.List;

import javax.persistence.EntityManager; 
import javax.persistence.PersistenceContext; 

import org.springframework.stereotype.Repository;

import com.tide.mobile.api.dao.UserDaoInterface;
import com.tide.mobile.domain.User;

/**
 * This class is used to access data for the User entity.
 *
 */
@Repository
public class UserDao implements UserDaoInterface{
  
  // An EntityManager will be automatically injected from entityManagerFactory
  @PersistenceContext
   private EntityManager entityManager;
  
  /**
   * Save the user in the database.
   */
  public long create(User user) {
	    entityManager.persist(user);
	    return user.getId();
  }
  
  /**
   * Delete the user from the database.
   */
  public void delete(User user) {
    if (entityManager.contains(user)){
      entityManager.remove(user);
    }else{
      entityManager.remove(entityManager.merge(user));
    }
  }
  
  /**
   * Return all the users stored in the database.
   */
  @SuppressWarnings("unchecked")
  public List<User> getAll() {
    return entityManager.createQuery("from User").getResultList();
  }

  /**
   * Return the user having the passed id.
   */
  public User getById(long id) {
    return entityManager.find(User.class, id);
  }

  /**
   * Update the passed user in the database.
   */
  public void update(User user) {
    entityManager.merge(user);
  }
  
} 
