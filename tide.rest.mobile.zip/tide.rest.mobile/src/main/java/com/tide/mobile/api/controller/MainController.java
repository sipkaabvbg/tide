package com.tide.mobile.api.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * This interface describes MainController methods
 * @author User
 *
 */
@Controller
@RequestMapping(method = RequestMethod.GET)
public interface MainController {

	  @RequestMapping("/")
	  @ResponseBody
	  public String index();
}
