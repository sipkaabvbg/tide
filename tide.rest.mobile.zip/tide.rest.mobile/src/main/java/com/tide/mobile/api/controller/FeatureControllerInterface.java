package com.tide.mobile.api.controller;
 
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.async.DeferredResult;


/**
 * This interface describes FeatureController methods
 * @author User
 *
 */

public interface FeatureControllerInterface {
	 /**
	   * Create a new Feature with an auto-generated id and description and name as passed 
	   * values.
	   */
	  @RequestMapping(
	          value="/feature/create", 
	          method = RequestMethod.POST, 
	          produces = MediaType.APPLICATION_JSON_VALUE,  
	          params = {"name","description"})  
	  @ResponseBody
	  public DeferredResult<ResponseEntity<?>> create(String name, String description);
	  /**
	   * Delete the feature with the passed id.
	   */
	  @RequestMapping(
	          value="/feature/delete", 
	          method = RequestMethod.DELETE, 
	          produces = MediaType.APPLICATION_JSON_VALUE,
	          params = {"featureId"})
	  @ResponseBody
	  public DeferredResult<ResponseEntity<?>> delete(long featureId);
	  /**
	   * Retrieve the id for the feature with the passed name.
	   */
	  @RequestMapping(
	          value="/feature/get-by-user", 
	          method = RequestMethod.GET, 
	          produces = MediaType.APPLICATION_JSON_VALUE,
	          params = {"userId"})
	  @ResponseBody
	  public DeferredResult<ResponseEntity<?>> getByUser(long userId);
	  
	  /**
	   * Update the description and the name for the user indentified by the passed id.
	   */
	  @RequestMapping(
	          value="feature/update", 
	          method = RequestMethod.PUT, 
	          produces = MediaType.APPLICATION_JSON_VALUE,
	          params = {"featureId", "featureName", "featureDescription"})
	  @ResponseBody
	  public DeferredResult<ResponseEntity<?>> updateName(long featureId, String featureName, String featureDescription);
}
