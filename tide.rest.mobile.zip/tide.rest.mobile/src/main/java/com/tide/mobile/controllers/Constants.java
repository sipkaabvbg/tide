package com.tide.mobile.controllers;

/**
 * Constants
 * @author User
 *
 */
public class Constants {

	private Constants() {
	}
	public static final String ADD_FEATURE_MESSAGE= "{\"message\":\"add-feature is OK\"}";
	public static final String REMOVE_FEATURE_MESSAGE = "{\"message\":\"remove-feature is OK\"}";
	public static final String USER_UPDATE_MESSAGE = "{\"message\":\"User succesfully updated!\"}";
	public static final String USER_DELETE_MESSAGE ="{\"message\":\"User succesfully deleted!\"}";
	public static final String FEATURE_UPDATE_MEASSGE= "{\"message\":\"Feature succesfully updated!\"}";
	public static final String FEATURE_DELETE_MEASSGE = "{\"message\":\"Feature succesfully deleted!\"}";
	public static final String FEATURE_REGISTERED_MEASSGE = "{\"message\":\"The feature with this name already registered, can't register feature with the same name.\"}";
	public static final String INDEX_MEASSGE= "Tide backend for mobile App started!";
}