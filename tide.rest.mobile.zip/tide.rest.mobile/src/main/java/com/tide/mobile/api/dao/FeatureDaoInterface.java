package com.tide.mobile.api.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.tide.mobile.domain.Feature;

/**
 * This interface describes FeatureDao methods
 * @author User
 *
 */
@Repository
@Transactional
public interface FeatureDaoInterface {
	  /**
	   * Save the feature in the database.
	   */
	  public void create(Feature feature);
	  
	  /**
	   * Delete the feature from the database.
	   */
	  public void delete(Feature feature);
	  
	  /**
	   * Return all the features stored in the database.
	   */ 
	  public List<Feature> getAll();
	  /**
	   * Return the feature having the passed id.
	   */
	  public Feature getById(long id);

	  /**
	   * Update the passed feature in the database.
	   */
	  public void update(Feature feature);
	  /**
	   * Return the feature having the passed name.
	   */
	  public Feature getByName(String name);
}
