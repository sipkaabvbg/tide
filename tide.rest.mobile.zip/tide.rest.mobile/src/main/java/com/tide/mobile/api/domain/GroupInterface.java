package com.tide.mobile.api.domain;

/**
 * This interface describes Group methods
 * @author User
 *
 */
public interface GroupInterface {

}
