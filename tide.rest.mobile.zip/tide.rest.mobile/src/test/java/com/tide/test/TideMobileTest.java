package com.tide.test;

import org.junit.Assert;
import org.junit.Test;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

//1 creating a user,
//2 creating a feature,
// 3 adding a feature to user,
// 4 checking all user's features.
public class TideMobileTest {

	private String output;
	private static final String URL = "http://localhost:8080";
	private static final String FEATURE_PATH = "/feature";
	private static final String CREATE_PATH = "/create";
	private static final String ADD_FEATURE_PATH = "/add-feature";
	private static final String GET_BY_USER_PATH = "/get-by-user";
	private static final String PARAMETER_NAME = "?name=";
	private static final String PARAMETER_USER_ID = "?userId=";
	private static final String PARAMETER_DESCRIPTION = "&description=";
	private static final String PARAMETER_FEATURE_NAME = "&featureName=";
	private static final String MESSAGE_ADD_FEATURE = "{\"message\":\"add-feature is OK\"}";
	private WebResource webResource;
	private ClientResponse response;
	private static final Client client = Client.create();

	@Test
	public void test() {

		String userId;
		String user = "testUser";
		String featureName = "featureName"+System.currentTimeMillis();
		String featureDescription = "featureDescription";

		userId = createClient(user);
		createFeature(featureName, featureDescription);
		addFeatureToUser(userId, featureName);
		getFeatureByUser(userId,featureName);

	}

	/**
	 * 1 creating a user
	 * 
	 * @param clientName
	 * @return
	 */
	private String createClient(String clientName) {
		String tempStart = "{\"userId\":";
		webResource = client.resource(URL + CREATE_PATH + PARAMETER_NAME + clientName);
		response = webResource.type("application/json").post(ClientResponse.class);

		checkReapons(response);
		output = response.getEntity(String.class);

		Assert.assertEquals(true, output.startsWith(tempStart));
		output = output.replace(tempStart, "");
		output = output.replace("}", "");
		return output;
	}

	/**
	 * 2 creating a feature
	 * 
	 * @param featureName
	 * @param featureDescription
	 */
	private void createFeature(String featureName, String featureDescription) {
		String tempStart = "{\"featureId\":";
		webResource = client.resource(URL + FEATURE_PATH + CREATE_PATH + PARAMETER_NAME + featureName
				+ PARAMETER_DESCRIPTION + featureDescription);
		response = webResource.type("application/json").post(ClientResponse.class);

		checkReapons(response);
		output = response.getEntity(String.class);

		Assert.assertEquals(true, output.startsWith(tempStart));
	}

	/**
	 * 3 adding a feature to user
	 * 
	 * @param userId
	 * @param featureName
	 */
	private void addFeatureToUser(String userId, String featureName) {

		webResource = client
				.resource(URL + ADD_FEATURE_PATH + PARAMETER_USER_ID + userId + PARAMETER_FEATURE_NAME + featureName);
		response = webResource.type("application/json").put(ClientResponse.class);

		checkReapons(response);
		output = response.getEntity(String.class);

		Assert.assertEquals(true, output.startsWith(MESSAGE_ADD_FEATURE));

	}

	/**
	 * 4 checking all user's features
	 * 
	 * @param userId
	 */
	private void getFeatureByUser(String userId, String featureName) {

		String testMessage = "{\"active_features\":[\"";
		webResource = client.resource(URL + FEATURE_PATH + GET_BY_USER_PATH + PARAMETER_USER_ID + userId);
		response = webResource.type("application/json").get(ClientResponse.class);

		checkReapons(response);
		output = response.getEntity(String.class); 
		Assert.assertEquals(true, output.startsWith(testMessage+featureName+"\"]}"));

	}

	private void checkReapons(ClientResponse response) {
		if (response.getStatus() != 200) {
			throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
		}
	}
}
